package Library;

import day50_Inheritance_Overriding.AccessModifiers;

public class AccessModifiersTest2 {

    public static void main(String[] args) {
        System.out.println(AccessModifiers.publicData );
       // System.out.println(AccessModifiers.protectedData);

    }

}
