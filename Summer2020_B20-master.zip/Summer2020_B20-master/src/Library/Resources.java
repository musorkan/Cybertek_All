package Library;

public class Resources {

    public static int a = 200;
    int b = 300;

    public static void method1(){
        System.out.println("Static method");
    }

    public void method2(){
        System.out.println("Instance method");
    }


}
