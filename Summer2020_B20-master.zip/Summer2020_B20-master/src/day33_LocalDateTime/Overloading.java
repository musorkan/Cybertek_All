package day33_LocalDateTime;

public class Overloading {



    public static void main(int[] kfc){
        System.out.println("int array");
    }


    public static void main(double[] arr){
        System.out.println("double array");
    }


    static public void main(String[] m) {

        System.out.println("String array");
        int[] arr ={1,2,3};

        /*
        println, substring, indexOf, replace, sort, toString, equals...
         */



    }





}
