package day04_Variables;
/*
 create a class called varibales_Practice:
        decleare the following variables:
        byte   num1 = 100;
        short   num2 = 10000;
        double   num3 = 3.5;
        float  num4 = 2.5f;
        long   num5 = 999999999999;
        int  num6 = 850000;

        print each of the variables above on the console
        double > float > long > int > short > byte
*/

public class varibales_Practice {

    public static void main(String[] args) {

      byte  num1 = 100;
      short num2 = 10000;
      double  num3 = 3.5;
      float  num4 = 2.5f;
      long num5 = 999999999999L;
      int  num6 = 850000;



        System.out.println(num1);
        System.out.println(num2);
        System.out.println(num3);
        System.out.println(num4);
        System.out.println(num5);
      System.out.println(num6);

    }


}
