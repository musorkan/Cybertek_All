package day04_Variables;

public class Variables_Practice2 {
// double > float > long > int > short > byte

    public static void main(String[] args) {
        int iNum = 50;
        long lNum = iNum;  //50

       // int iNum2 = lNum;
        float fNum = lNum; // 50.0


    //    float fNum = 500;

    //    float 123fNum = 500;

        float fNum123 = 500;
        float num$ = 1000;

        //1,000,000
    int num1 = 1_000_000;

        System.out.println(num1);

        int num2 ;
        num2 = 5000;  // 5000

        System.out.println(num2); // 5000

        num2 = 2000;  // 2000

        System.out.println(num2);   // 2000



    }

}
