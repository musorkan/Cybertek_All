package Office_Hours.Practice_06_24_2020;

public class Switch_ShortQuiz {

    public static void main(String[] args) {
        //q1
        int a = 10;  // float, long, boolean, double
        switch (a){ // 15
            case 10:
                System.out.println("Monday");
                break;

            case 11:
                System.out.println("Tuesday");
                break;

            case 12:
                System.out.println("Wednesday");
                break;

            default:
                System.out.println("Friday");

        }




    }

}
