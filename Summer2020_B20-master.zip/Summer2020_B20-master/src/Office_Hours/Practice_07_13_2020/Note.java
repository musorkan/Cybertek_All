package Office_Hours.Practice_07_13_2020;

public class Note {

    /*
    07/13/2020
Practice Topic: String & loops

package name: Practice_07_13_2020

Task:
	Frequency of characters

		"JAVA";
		J1A2V1

		"DDEEEFFFF";
		D2E3F4


		steps:
			remove duplicates "DEF"
			Frequnecy:        2  3  4
			combine:   D2E3F4


tomorrow:
	Unique


     */
}
