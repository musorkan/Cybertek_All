package Office_Hours.Practice_07_14_2020;

public class Notes {
    /*
    07/14/2020
Practice Topic: String & loop

package name: Practice_07_14_2020

Tasks:
	finding the uniques

	unique: frequency is 1




next office hour:
	finding the frequency of the word from a string
     */
}
