package Office_Hours.Practice_07_28_2020;

public class ClassNotes {
    /*
    07/28/2020
Practice Tipic: Methods

Package name: Practice_07_28_2020

practice task:
	1. method: reverseString

	2. method: palindrome Test

			"ABC"
			"CBA"

			"ABC".equalsIgnoreCase("CBA")




     */
}
