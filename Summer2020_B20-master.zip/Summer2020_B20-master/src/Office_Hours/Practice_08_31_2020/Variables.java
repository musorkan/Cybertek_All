package Office_Hours.Practice_08_31_2020;

public class Variables {
    int z = 400; // instance variable

    static int y = 600;  // static variable

    public static void main(String[] args) {

        int a = 100;
        System.out.println(a);

       // static int b = 200;
        int c = 300; // local


    }

}
