package Office_Hours.Practice_08_31_2020;

public class Quiz {
    static String name = "Aaron";

    public static void main(String[] args) {  // Daniel
        System.out.println("Daniel");
    }

    public static void print(String str){
        System.out.println(str);
    }

    static{
        print(name);  // Aaron
    }


}
