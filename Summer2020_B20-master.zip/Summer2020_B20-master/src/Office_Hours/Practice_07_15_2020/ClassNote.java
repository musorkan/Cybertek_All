package Office_Hours.Practice_07_15_2020;

public class ClassNote {

    /*
    07/15/2020
Practice Topic: String & loops

package name: Practice_07_15_2020

Task:
     write a program that can find the frequency of a word from a string(not from a sentence)
     Ex:
        input:
            Cat Cat Cat
            Cat


        output:
            2

        input:
            JavaJavaJava
            Java

        output:
            3

     */

}
