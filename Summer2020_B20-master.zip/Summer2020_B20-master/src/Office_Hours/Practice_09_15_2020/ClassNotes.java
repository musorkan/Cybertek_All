package Office_Hours.Practice_09_15_2020;

public class ClassNotes {
    /*
    09/15/2020
Practice Topic: Inheritance Review
				Math class

Package name: Practice_09_15_2020

Math class: presented in "java.lang"

Object class : presented in "java.lang"
			implicitly implemented to all the classes



     */
}
