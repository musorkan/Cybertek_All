package Office_Hours.Practice_09_08_2020;

public class Data {

     private int a = 100;

    private static  void  method1(){

    }

    public void method2(){
        System.out.println(a);
        method1();
    }


}


class Test{

    public static void main(String[] args) {
        Data obj1 = new Data();

      //  System.out.println( obj1.a );
    //    obj1.method1();


    }

}
