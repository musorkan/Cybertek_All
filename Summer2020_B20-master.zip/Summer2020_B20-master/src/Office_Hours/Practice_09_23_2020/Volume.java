package Office_Hours.Practice_09_23_2020;

public interface Volume {

    double calculateVolume();  // public abstract

}
