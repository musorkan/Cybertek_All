package Office_Hours.Practice_09_23_2020;

public abstract class Shape {

    public double area;
    public double perimeter;
    public double volume;

    public abstract double calculateArea();
    public abstract double calculatePerimeter();

}
