package Office_Hours.Practice_07_21_2020;

public class note {
    /*
    07/21/2020
Practice topic:  Arrays

Package name: Practice_07_21_2020

Task:
	1. Arrays: Descending order

		solution 1: for loop

		solution 2: for each loop ( you need extra variable for index number)





tomorrow:
	combining arrays

     */
}
