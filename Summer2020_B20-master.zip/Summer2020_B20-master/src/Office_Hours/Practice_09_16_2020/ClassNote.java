package Office_Hours.Practice_09_16_2020;

public class ClassNote {

    /*
    09/16/2020
Practice Topic: Exceptions
					unchecked & checked

					try & catch & finally
					throws

					throw

package name: Practice_09/16/2020


exception handling:

	1. try&catch (proper way): in a block

			try{
				exception code
			}catch(ExceptionClass  e){
				e.getMessage()
			}finally{
					// always gets executed
			}

		All exceptions in selenium are unchecked exception


	2. throws(temporary fix): method signature, for chekced exception
							caller will be responsible (bypass)





throw: to manullay throw exception

		browserName: chrome, firefox, safari, edge, IE..

			if(browserName.equals("cybertek")){
				throw ExceptionObject
			}




     */

}
