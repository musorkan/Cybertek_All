package Office_Hours.Practice_08_26_2020;

public class task {

     static int a;

    public static void main(String[] args) {
        a = 1000;

        System.out.println(a);
       // method();

    }

    static{
       a= 500;
        //method();
    }

    public void method(){
        System.out.println(a);
    }



}
