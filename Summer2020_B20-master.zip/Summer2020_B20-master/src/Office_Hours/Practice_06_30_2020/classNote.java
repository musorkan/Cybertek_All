package Office_Hours.Practice_06_30_2020;

public class classNote {

    /*
        06/30/2020
    Practice Topic: If statement
                    Ternary

    create a sub Package named Practice_06_30_2020 under the package "Office_hours"


    if(conition){  // for one condition
        statementA;
    }


    if(Condition){  //for 2 condition
        statementA;
    }else{
        statementB;
    }



    if(Condition){  // for more than 2 condition
        statementA
    }else if(Condition){
        statementB
    }else{
        statementC
    }

    nested: pre-condition

        pre-condition: 0 - 100 ==> A, B, C, D, F
        otherwise ==> Invalid


    ternary:
            ? is if, conditions are places before
            : else


     */

}
