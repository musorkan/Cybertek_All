package Office_Hours.Practice_09_09_2020;

public class ClassNotes {
    /*
    09/09/2020
Practice Topics: Inheritance

package name: Practice_09_09_2020


Inheritance: extends

		Samsung  extends  Phone

		Iphone extends Phone

		Nokia extends Phone

		sub class inherits the variables and methods (visible one)

		advantages:
				re-usable
				easy to maintain


IS A:
		Samsung IS A Phone
		Iphone IS A Phone
		Nokia IS A Phone


access modifiers that are visible to the sub class:
		public: ALWAYS
		protected: ALWYAS (outside package , just for sub classes)
		default: ONLY within the same package
		private: NEVER




Phone: brand, model, price, madeIn, call(), text()
	static: brand, madeIn,
	insatnce: model, price, call(), text(), toString()


Samsung: brand, model, price, madeIn, call(), text(), toString(), screenSize, isTouchScreen


Iphone: brand, model, price, madeIn, call(), text(), toString(), screenSize, isTouchScreen


Nokia: brand, model, price, madeIn, call(), text(), toString(), screenSize, isTouchScreen



overriding: one method with different implemntations



     */
}
