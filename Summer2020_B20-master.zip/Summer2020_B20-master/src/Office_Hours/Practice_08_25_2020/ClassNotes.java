package Office_Hours.Practice_08_25_2020;

public class ClassNotes {

    /*
    08/25/1010
Practice Topics: ArrayList
				 Collections Utility


package name: Practice_08_25_2020


Array ===> Arrays
Collection ===> Collections
Map


array: fixed size.
		supports primitive or non primitive

Collection: dynamic size (add, remove)
			ONLy supports non-primitives


ArrayList:
	add:
	addAll(CollectionType):

	remove:
	removeAll:
	retainAll:
	removeIf:
	clear():


	set():


Collections Utility:
		swap:
		sort:
		max:
		min:
		frequency:


Tomorrow: 5pm ~ 7pm  review section for javatutles
		custom methods
		method overloading




     */

}
