package Office_Hours.Practice_06_17_2020;

public class ClassNote {
    /*
    06/17/2020
Practice topic: sub-package
				Operators
					--, ++, &&, ||, !

warmup:
		Create a package named Office_Hours

		Practice_06_17_2020

			Post_VS_Pre



--: decreases the value by 1
	pre: decreases the value by 1 right away
			--a, --b...

	post: passes the current value, then decreases it by 1
			a--, b-- ...


++: increase the value by 1
	pre: increase the value by 1 right away
			++a, ++b

	post: passes the current value, then increases it by 1


Logical Operators:  returns boolean
	!: opposite

		!false == true   ===> true
		!!true ==> true
		!!!true ==> false

	||: or, either
		only returns false if all conditions are false

	&&: and, both
		only returns true if all conditions are true









     */
}
