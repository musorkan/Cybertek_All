package Office_Hours.Practice_09_02_2020;

public class ClassNote {
    /*
    09/02/2020
Practice Topic: Constructor
				static block

package name: Practice_09_02_2020


object
	new Constructor


Circle:
	Attributes:
			radius, PI, diameter

		static: PI
		instance: radius, diameter


	circle1:  r=3    d=6		PI=3.14    area() = 30..

	circle2:  r=5    d=10		PI=3.14    area() = 80..

	circle3:  r=6    d=12		PI=3.14    area() = 100..


reg methods:
		AM   specifier  return-Type  name(Parameter){

		}


constructor: special methods

		AM className(Parameter){

		}




     */
}
