package Office_Hours.Practice_07_20_2020;

public class notes {

    /*
    07/20/2020
Practice Topic: nested loop & arrays

package name: Practice_07_20_2020

Task:
	write a program that can find the maximum number from any given two dimensional array

		solution one: use nested for loops

		solution two: use nested for each loops

		solution three: use for loop and for each loop together


		class: Max_2DArray
     */
}
