package day30_CustomMethods;

public class Recap {


     static public  void method1(){

    }


}
