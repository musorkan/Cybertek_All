package day20_WhileLoops;

public class WhileLoop {

    public static void main(String[] args) {

        if(true){
            System.out.println("Hello World");
        }

        System.out.println("=====================================");

        while(true){
            System.out.println("Hello World");
        }

        /*
        for(int i= 0; i ==0;){

        }
         */



    }

}
