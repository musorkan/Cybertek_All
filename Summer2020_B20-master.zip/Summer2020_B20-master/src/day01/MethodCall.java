package day01;

public class MethodCall {

    public static void main(String[] args) {

        int[] numbers = {300,200,100, 10000, 300000, -5000, 40000};





    }


}
