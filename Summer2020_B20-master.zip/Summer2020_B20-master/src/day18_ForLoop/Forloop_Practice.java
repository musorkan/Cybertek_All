package day18_ForLoop;

public class Forloop_Practice {

    public static void main(String[] args) {


        for( int i = 1;  i <= 5; ++i ){ //i: 1, 2, 3, 4, 5, 6

            System.out.println("Cybertek Batch 20"); //5

        }

        System.out.println("=============================================");

        for(int i = 1;  i <= 100; i++ ){
            System.out.print(i+" ");
        }

        System.out.println();

        System.out.println("=================================================");

        for(int i = 100; i == 1; i-- ){
            System.out.print(i+" ");
        }





    }

}
