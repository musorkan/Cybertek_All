package day18_ForLoop;

public class ForLoop {

    public static void main(String[] args) {

        System.out.println("Hello World");
        System.out.println("Hello World");
        System.out.println("Hello World");
        System.out.println("Hello World");
        System.out.println("Hello World");

        System.out.println("====================================");

        for( int i = 0; i < 10; i += 1 ){  //i: 0, 1, 2,3,4,5,6,7,8,9,10

            System.out.println("Hello World");

        }





    }

}
