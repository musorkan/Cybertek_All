package day41_toString_Practice;

public class CarObjects {

    public static void main(String[] args) {

        Car car1 = new Car();
        car1.setCarInfo("BMW", "X5", 2019, 50000, "Red");

        System.out.println(car1);





    }

}
