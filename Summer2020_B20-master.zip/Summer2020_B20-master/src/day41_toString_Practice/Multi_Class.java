package day41_toString_Practice;

public class Multi_Class {
    public static void main(String[] args) {
        System.out.println("Class 1");
    }

}



class Test1{

    public static void main(String[] args) {
        System.out.println("Class 2");
    }

}

class Test2{

    public static void main(String[] args) {
        System.out.println("Class 3");
    }
}
