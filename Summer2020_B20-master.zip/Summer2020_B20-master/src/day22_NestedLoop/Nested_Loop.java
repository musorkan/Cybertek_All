package day22_NestedLoop;

public class Nested_Loop {

    public static void main(String[] args) {

        for(int i = 1; i <= 5; i++){
            System.out.print(i+" ");
        }
        System.out.println();

        for(int i = 1; i <= 5; i++){
            System.out.print(i+" ");
        }
        System.out.println();

        for(int i = 1; i <= 5; i++){
            System.out.print(i+" ");
        }
        System.out.println();

        for(int i = 1; i <= 5; i++){
            System.out.print(i+" ");
        }
        System.out.println();

        for(int i = 1; i <= 5; i++){
            System.out.print(i+" ");
        }
        System.out.println();





    }

}
