package day43_Static;

public class staticBlock3 {

    static int a;
    static int b;
    static int c;

    static{
        a = 100;
        b = 200;
        c = 300;
    }

/*
    public static void main(String[] args) {
        a = 100;
        b = 200;
        c = 300;
    }
*/

}
