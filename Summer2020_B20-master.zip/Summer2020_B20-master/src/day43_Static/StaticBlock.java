package day43_Static;

public class StaticBlock {


    public static void main(String[] args) {
        System.out.println("Main method");
    }

    static {
        System.out.println("Static block");
    }


}
