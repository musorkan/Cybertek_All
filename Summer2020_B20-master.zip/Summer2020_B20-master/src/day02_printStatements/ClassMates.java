package day02_printStatements;

public class ClassMates {

    public static void main(String[] args){
        System.out.println("   Aalia");
        System.out.println("   Sefika");
        System.out.println("   Ayhan");
        System.out.println("   Tahsin");
        System.out.println("   Zaiiadin");

    }


}
