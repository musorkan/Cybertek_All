package day02_printStatements;

public class ShortCuts {

    public static void main(String[] args) {
        System.out.println();
        System.out.println();


    }

}
