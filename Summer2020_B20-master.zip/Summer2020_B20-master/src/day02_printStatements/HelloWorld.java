package day02_printStatements;

public class HelloWorld {

    public static void main( String[] args ) {  //main method

        System.out.println( "Hello Wolrd" );

    }

}

                        /*
                        Today we learned HelloWorld
                           struggles are: print statement
                                          main method

                                          date:
                         */
