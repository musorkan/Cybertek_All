package day02_printStatements;

public class HelloCybertek {

    public static void main (String[] args){

        System.out.println("Hello Cybertek");
        System.out.println("Hello Batch 20");
        System.out.println("        I Love Java Programming Language");

    }


}
