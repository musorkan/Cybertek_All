package day0;

public class MethodCall {

    public static void main(String[] args) {

        String str = "Cybertek School";


        String str2 = "abcabcaaaaabbbbbbcccccddddeeeeeee";


    }

}
