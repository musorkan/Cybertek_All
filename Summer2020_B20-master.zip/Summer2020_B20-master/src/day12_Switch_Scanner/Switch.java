package day12_Switch_Scanner;

public class Switch {

    public static void main(String[] args) {

        int a = 1;

        switch(a){

            case 5:
                System.out.println("Five");
                break;

            case 1:
                System.out.println("One");
                break;

            default:
                System.out.println("Invalid Case");

        }




    }

}
