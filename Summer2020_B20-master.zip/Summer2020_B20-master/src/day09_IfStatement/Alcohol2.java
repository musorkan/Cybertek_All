package day09_IfStatement;

public class Alcohol2 {

    public static void main(String[] args) {
        int age = 26;

        if(age >= 21){
            System.out.println("You can buy alcohol");
        }else{  // age < 21
            System.out.println("You can not buy alcohol");
        }


    }

}
