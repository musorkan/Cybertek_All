package day03_sequences_Variables;

public class EmployeeInfo {  //this is a class header

    public static void main(String[] args) {  //this is main method, used for running the java codes

        System.out.println("Company Name: Bank Of America");
                //print statements is used for printing
        System.out.println("Employee Name: John");
        System.out.println("Employee ID: 12345");
        System.out.println("Job Title: SDET");
        System.out.println("Salary: $100000");
    }

}



    // today is: 06/06/2020

                /*
                Today i have learned java
                topics are:
                            1. print statement
                            2. variables
                            ....
                 */
