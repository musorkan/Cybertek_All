package day03_sequences_Variables;

public class EscapeSequences {
    public static void main(String[] args) {

        System.out.println("Hello Everyone \nMy name is Cybertek");
        System.out.println("\tI am in Virginia\n");
        System.out.println("\n\n\t\t\tI love programming");

        System.out.println("\\");  // this prints me one back slash
        System.out.println("/");  // this prints me one front slash

        System.out.println("\\\\"); // this prints me two back slash
        System.out.println("//"); // this prints me two front slash


        System.out.println("My name is \'Muhtar\'");   // 'Muhtar'
        System.out.println("My name is 'Muhtar'");  // 'Muhtar'

        System.out.println("My favorite TV-series: \"Game of Thrones\"");


    }

}
