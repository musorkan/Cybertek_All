package day03_sequences_Variables;

public class Print_VS_Println {

    public static void main(String[] args) {
        System.out.println("A"); // A + new line
        System.out.println("B"); // B + new line
        System.out.println("C"); // C +new line

        System.out.println("=======================");


        System.out.print("A"); // A
        System.out.print("B"); // B
        System.out.print("C"); // C



    }

}
