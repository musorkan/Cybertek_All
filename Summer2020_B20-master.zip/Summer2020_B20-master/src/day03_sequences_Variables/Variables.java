package day03_sequences_Variables;
/*
declare variables:
            DataType  variableName = Data;
 */

public class Variables {

    public static void main(String[] args) {
        // length: 11, width: 12,  area :

        byte length = 11;
        byte width = 12;
        System.out.println( length * width );

        // 140
    //   byte num1 = 140;

        short num2 = 140;

        // 40000
      //  short salaray = 40000;

        int salary = 40000;

     //   int largenumber = 99999999999;

        long  largenumber = 99999999999L;


          int score = 100;

        System.out.println(score);

        // PI = 3.14

        double PI = 3.14;
        System.out.println(PI);

      float decimal1 = 3.5f;



    }

}
