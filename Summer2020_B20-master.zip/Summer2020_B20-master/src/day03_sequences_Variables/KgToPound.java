package day03_sequences_Variables;

public class KgToPound {

    public static void main(String[] args) {
        double kg = 83.5;
        double pound = kg * 2.2;

        System.out.println(pound);

    }

}
