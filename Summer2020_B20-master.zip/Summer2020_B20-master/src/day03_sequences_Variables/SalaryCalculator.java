package day03_sequences_Variables;
/*
task:               100000,  0.28
        variables: salary, tax

                totalTax = salary * tax;
               salaryAfterTax =   salary - totalTax

               100000 ,     0.28;
                100000 * 0.28 = 28000;
                100000 - 28000 = 72000;
 */
public class SalaryCalculator {

    public static void main(String[] args) {
        double salary = 150000.0;
        double tax = 0.28;

        double totalTax =   salary * tax;  // 28000
        double salaryAfterTax = salary - totalTax;  //72000

        System.out.println(salaryAfterTax);


        int a =100;
        long A = 200;

        //float tax=  0.5;

      //  int 1num = 123;
      //  int @num = 1234;

        double number_ = 123;
        double number$ = 1234;

        //long new = 1235;
     //   long throw = 123456;
        int itemsOrdered = 4000;

        //int 123 =123;

        // $ or _

      //  int taxrate = 30;
      //  int TaxRate = 50;



    }


}
