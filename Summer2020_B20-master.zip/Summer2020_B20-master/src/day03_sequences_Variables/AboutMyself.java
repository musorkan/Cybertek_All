package day03_sequences_Variables;
/*
 Task:
        1. write a paragraph to tell us about yourself
        MUST include: favorite TV-Series, Books
        name of TV-Series and title of the books MUST be printed with “”
        your name MUST be printed within ''
*/

public class AboutMyself {

    public static void main(String[] args) {
        System.out.println("Hello Everyone");
        System.out.println("\tMy name is 'Muhtar', my favorite book is \"Java\", my favorite TV-Series is \"Prison Break\"");

    }


}
