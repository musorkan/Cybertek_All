package day03_sequences_Variables;
/*
task:

        ^
       / \
      /   \
     /     \
    /       \
    ---------
*/

public class Triangle {

    public static void main(String[] args) {
        System.out.println("\t\t     ^");
        System.out.println("\t\t    / \\");
        System.out.println("\t\t   /   \\");
        System.out.println("\t\t  /     \\");
        System.out.println("\t\t /_______\\");

    }


}
