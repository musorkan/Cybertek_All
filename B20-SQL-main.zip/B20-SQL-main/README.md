# B20-SQL
SQL Class Repository for Batch 20 
