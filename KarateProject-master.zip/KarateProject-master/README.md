# KarateProject
